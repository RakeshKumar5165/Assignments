package soap;

import java.util.*;
import javax.jws.WebMethod;
import javax.jws.WebService;
@WebService
public interface assignment {
    @WebMethod
	public ArrayList<String> playersname(String name);
    @WebMethod
	public String add(String name);
    @WebMethod
	public void remove(String name);
}
