package soap;

import java.util.ArrayList;

import javax.jws.WebService;
//import javax.xml.ws.Endpoint;

@WebService(endpointInterface="soap.assignment")
public class assignmentimpl implements assignment {
	ArrayList<String> a=new ArrayList<String>();
	public ArrayList<String> playersname(String name)
	{
	  return a;	
	}
	public String add(String name)
	{
		a.add(name);
		return "added";
	}
	public void remove(String name)
	{  int z=a.indexOf(name);
		a.remove(z);
	}

}
