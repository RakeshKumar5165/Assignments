package soap;
import javax.xml.ws.Endpoint;
public class assignmentmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Endpoint.publish("http://localhost:8080/WSD/assignment", new assignmentimpl()) ;
	}

}
